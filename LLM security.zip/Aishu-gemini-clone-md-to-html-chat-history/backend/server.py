import os
import re
from flask import Flask, request, jsonify
from transformers import pipeline
import google.generativeai as genai
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# 🔐 Gemini API key setup
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyAnsvZPu9QCTUvGN5F9AfU5MisZEt5WUn4")
genai.configure(api_key=GEMINI_API_KEY)

# 📦 Load ML pipelines
sentiment_pipe = pipeline("text-classification", model="cardiffnlp/twitter-roberta-base-sentiment")
harmful_pipe = pipeline("text-classification", model="domenicrosati/deberta-v3-xsmall-beavertails-harmful-qa-classifier")

# 🧠 Gemini configuration
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}
model = genai.GenerativeModel(model_name="gemini-2.0-flash", generation_config=generation_config)
chat_session = model.start_chat(history=[])

# 🧠 Tab-based in-memory storage: {tab_id: [{"user": message, "blocked": True/False}]}
tabs = []  # Each tab is a list of message dicts

# 🔍 Utility functions
def split_text(text):
    return re.split(r'(?<=[.!?])\s+', text)

def classify_sentiment(text):
    if not text.strip():
        return "Neutral"
    parts = split_text(text)
    for part in parts:
        result = sentiment_pipe(part)
        if result[0]['label'] == "LABEL_0":  # Negative
            return "Negative"
    return "Positive" if "LABEL_2" in result[0]['label'] else "Neutral"

def classify_harmfulness(text):
    if not text.strip():
        return "Safe"
    parts = split_text(text)
    for part in parts:
        result = harmful_pipe(part)
        label = result[0]['label']
        score = result[0]['score']
        if label == "LABEL_0" and score >= 0.85:  # Unsafe
            return "Unsafe"
    return "Safe"

def find_related_tab(user_message):
    for idx, tab in enumerate(tabs):
        blocked_msgs = [msg["user"] for msg in tab if msg["blocked"]]
        if blocked_msgs:
            blocked_text = "\n".join(blocked_msgs)
            prompt = (
                f"Is the new message related to any of these previously blocked ones?\n"
                f"Blocked History: {blocked_text}\n"
                f"New Message: {user_message}\n"
                f"Respond only with 'Yes' or 'No'."
            )
            response = model.generate_content(prompt)
            if response.text.strip().lower() == "yes":
                return idx, True

        unblocked_msgs = [msg["user"] for msg in tab if not msg["blocked"]]
        if unblocked_msgs:
            unblocked_text = "\n".join(unblocked_msgs)
            prompt2 = (
                f"Are the following two messages related?\n"
                f"Past messages: {unblocked_text}\n"
                f"New message: {user_message}\n"
                f"Respond only with 'Yes' or 'No'."
            )
            response2 = model.generate_content(prompt2)
            if response2.text.strip().lower() == "yes":
                return idx, False

    return None, False  # No related tab found

# 🔥 MAIN ROUTE
@app.route("/process", methods=["POST"])
def process_message():
    try:
        data = request.json
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({"error": "Empty message"}), 400

        print(f"\n🎯 Received Message: {user_message}")

        tab_index, related_to_blocked = find_related_tab(user_message)

        if related_to_blocked:
            print(f"🚫 Related to blocked content — Added to Tab {tab_index}")
            tabs[tab_index].append({"user": user_message, "blocked": True})
            return jsonify({"response": "Sorry, I cannot assist.", "tab_index": tab_index, "tab_details": tabs[tab_index]}), 200

        if tab_index is None:
            tabs.append([])
            tab_index = len(tabs) - 1
            print(f"🌟 No related tab found — New Tab {tab_index} created")
        else:
            print(f"🗂️ Found related conversation — Added to Tab {tab_index}")

        # Classify with ML Model
        sentiment = classify_sentiment(user_message)
        harmfulness = classify_harmfulness(user_message)

        print(f"   Sentiment: {sentiment}")
        print(f"   Harmfulness: {harmfulness}")

        if sentiment == "Negative" or harmfulness == "Unsafe":
            print(f"🚫 Message Blocked due to Sentiment/Harmfulness — Added to Tab {tab_index}")
            tabs[tab_index].append({"user": user_message, "blocked": True})
            return jsonify({"response": "Sorry, I cannot assist.", "tab_index": tab_index, "tab_details": tabs[tab_index]}), 200

        # Passed all checks → send to Gemini
        tabs[tab_index].append({"user": user_message, "blocked": False})
        response = chat_session.send_message(user_message)
        print(f"✅ Message sent to Gemini — Response returned — Stored in Tab {tab_index}")
        return jsonify({"response": response.text, "tab_index": tab_index, "tab_details": tabs[tab_index]}), 200

    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({"error": str(e)}), 500

# 🚀 Launch app
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
