import React, { useContext } from 'react';
import './Main.css';
import { assets } from '../../assets/assets';
import { Context } from '../../context/Context';
import { marked } from "marked";
import DOMPurify from 'dompurify';

const Main = () => {
    // Safely destructure context with defaults
    const context = useContext(Context) || {};
    const { 
        onSent = () => console.warn('onSent not implemented'),
        showResult = false, 
        loading = false,
        setInput = () => {},
        input = '',
        chatEndRef = { current: null },
        chats = {},
        activeChatId = null,
        handleCardClick = () => {}
    } = context;

    const handleSend = () => {
        if (input.trim()) {
            onSent();
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && input.trim()) {
            onSent();
        }
    };

    // Safely get current chat messages
    const currentChat = activeChatId ? chats[activeChatId] || [] : [];

    return (
        <div className='main'>
            <div className='nav'>
                <p>Gemini</p>
                <img src={assets.user_icon} alt="user profile" />
            </div>
            
            <div className='main-container'>
                {!showResult || currentChat.length === 0 ? (
                    <>
                        <div className='greet'>
                            <p><span>Hello, </span></p>
                            <p>How can I help you today?</p>
                        </div>
                        <div className="cards">
                            <div className="card" onClick={() => handleCardClick("Suggest beautiful places to see on an upcoming road trip")}>
                                <p>Suggest beautiful places to see on an upcoming road trip</p>
                                <img src={assets.compass_icon} alt="road trip suggestions" />
                            </div>
                            <div className="card" onClick={() => handleCardClick("Briefly summarize this concept: urban planning")}>
                                <p>Briefly summarize this concept: urban planning</p>
                                <img src={assets.bulb_icon} alt="concept explanation" />
                            </div>
                            <div className="card" onClick={() => handleCardClick("Brainstorm team bonding activities for our work retreat")}>
                                <p>Brainstorm team bonding activities for our work retreat</p>
                                <img src={assets.message_icon} alt="team activities" />
                            </div>
                            <div className="card" onClick={() => handleCardClick("Improve the readability of the following code")}>
                                <p>Improve the readability of the following code</p>
                                <img src={assets.code_icon} alt="code improvement" />
                            </div>
                        </div>
                    </>
                ) : (
                    <div className='chat-history'>
                        {currentChat.map((message, index) => (
                            <div key={`${activeChatId}-${index}`} className='result'>
                                {message.role === "user" ? (
                                    <div className='result-title'>
                                        <img src={assets.user_icon} alt="User"/>
                                        <p>{message.content}</p>
                                    </div>
                                ) : (
                                    <div className="result-data">
                                        <img src={assets.gemini_icon} alt='Gemini' />
                                        {loading && index === currentChat.length - 1 ? (
                                            <div className='loader'>
                                                <hr />
                                                <hr />
                                                <hr />
                                            </div>
                                        ) : (
                                            <div 
                                                dangerouslySetInnerHTML={{ 
                                                    __html: DOMPurify.sanitize(marked(message.content || '')) 
                                                }} 
                                            />
                                        )}
                                    </div>
                                )}
                            </div>
                        ))}
                        <div ref={chatEndRef} />
                    </div>
                )}

                <div className='main-bottom'>
                    <div className='search-box'>
                        <input
                            onChange={(e) => setInput(e.target.value)}
                            value={input}
                            type='text'
                            placeholder='Enter a prompt here'
                            onKeyPress={handleKeyPress}
                            aria-label="Chat input"
                        />
                        <div>
                            <img src={assets.gallery_icon} alt='Upload image' />
                            <img src={assets.mic_icon} alt='Voice input' />
                            {input.trim() && (
                                <img 
                                    onClick={handleSend} 
                                    src={assets.send_icon} 
                                    alt='Send message' 
                                    role="button"
                                />
                            )}
                        </div>
                    </div>
                    <p className='bottom-info'>
                        Gemini may display inaccurate info, so double-check its responses. Your privacy and Gemini Apps.
                    </p>
                </div>
            </div>
        </div>
    );
}

export default Main;