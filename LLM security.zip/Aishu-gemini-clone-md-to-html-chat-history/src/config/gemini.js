import { GoogleGenerativeAI } from "@google/generative-ai";

// Set up API key
const API_KEY = "AIzaSyChBHjpFC40XDXpDe15RETSW93OYUPxPq0"; // Replace with your actual API key
const genAI = new GoogleGenerativeAI(API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 40,
  maxOutputTokens: 8192,
  responseMimeType: "text/plain",
};

// Function to classify input before sending it to Gemini
async function classifyInput(userMessage) {
  try {
    const response = await fetch("http://localhost:8000/classify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: userMessage }),
    });

    const result = await response.json();
    return result; // { sentiment: "Positive", harmfulness: "Safe" }
  } catch (error) {
    console.error("Error classifying input:", error);
    return { sentiment: "Unknown", harmfulness: "Unknown" };
  }
}

// Function to interact with Gemini API
// Function to send user input to the backend for classification & Gemini response
async function run(prompt) {
  if (!prompt.trim()) {
    console.error("Error: No prompt provided.");
    return "Error: No prompt provided.";
  }

  try {
    // ✅ Send input to backend first
    const response = await fetch("http://localhost:8000/process", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: prompt }),
    });

    const result = await response.json();
    
    // ✅ Return either the blocked message or Gemini's response
    return result.response; 
  } catch (error) {
    console.error("Error communicating with backend:", error);
    return "Error: Unable to generate response.";
  }
}

export default run;
